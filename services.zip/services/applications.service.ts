import { supabase } from "@/services/supabase";
import {
  getCurrentVoyUserId,
  getJobById,
  listMyApplications,
  updateJobStatus,
  VoyJobApplicationRow,
} from "@/services/jobs.service";
import { JobStatus } from "@/types";
import { ensureChatForApplication } from "@/services/chat";
import { getAuthUserIdByVoyUserId } from "@/services/users.service";

const timestampNow = () => new Date().toISOString();

export async function listApplicationsByWorker(): Promise<VoyJobApplicationRow[]> {
  return await listMyApplications();
}

export async function listByJob(jobId: string): Promise<VoyJobApplicationRow[]> {
  const { data, error } = await supabase
    .from("VoyJobApplications")
    .select(
      `*,
      helper:VoyUsers!helper_user_id(
        id,
        full_name,
        avatar_url,
        city,
        district,
        verification_status
      )`
    )
    .eq("job_id", jobId)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as VoyJobApplicationRow[];
}

export async function getApplicationById(applicationId: string): Promise<VoyJobApplicationRow | null> {
  const { data, error } = await supabase
    .from("VoyJobApplications")
    .select("*")
    .eq("id", applicationId)
    .maybeSingle();
  if (error) throw error;
  return (data as VoyJobApplicationRow) || null;
}

export async function applyToJob(jobId: string, proposal: number | null, message?: string) {
  const me = await getCurrentVoyUserId();
  const job = await getJobById(jobId);
  if (!job) throw new Error("Trabajo no encontrado.");
  const row = {
    job_id: jobId,
    helper_user_id: me,
    message: message ?? null,
    proposed_price: proposal ?? null,
    status: "PENDING",
  };
  const { data, error } = await supabase
    .from("VoyJobApplications")
    .upsert(row, { onConflict: "job_id,helper_user_id" })
    .select("*")
    .maybeSingle();
  if (error) throw error;
  const application = (data as VoyJobApplicationRow) || null;
  if (!application) {
    throw new Error("No se pudo registrar la solicitud.");
  }
  const clientAuthUserId = await getAuthUserIdByVoyUserId(job.creator_user_id);
  if (!clientAuthUserId) {
    throw new Error("No se pudo obtener el identificador del anunciante.");
  }
  await ensureChatForApplication({
    applicationId: application.id,
    jobId,
    clientUserId: clientAuthUserId,
    helperUserId: me,
  });
  return (data as VoyJobApplicationRow) || null;
}

async function updateStatus(
  applicationId: string,
  status: VoyJobApplicationRow["status"],
  extra?: Partial<VoyJobApplicationRow>
) {
  const payload: any = {
    status,
    updated_at: timestampNow(),
  };
  if (status === "ACCEPTED" || status === "REJECTED" || status === "CANCELLED" || status === "COMPLETED") {
    payload.responded_at = timestampNow();
  }
  if (extra) Object.assign(payload, extra);

  const { data, error } = await supabase
    .from("VoyJobApplications")
    .update(payload)
    .eq("id", applicationId)
    .select("*")
    .single();
  if (error) throw error;
  return data as VoyJobApplicationRow;
}

async function rejectOtherApplications(jobId: string, excludeId: string) {
  const { data, error } = await supabase
    .from("VoyJobApplications")
    .update({
      status: "REJECTED",
      responded_at: timestampNow(),
      updated_at: timestampNow(),
    })
    .eq("job_id", jobId)
    .neq("id", excludeId)
    .not("status", "eq", "REJECTED");
  if (error) throw error;
  return data as VoyJobApplicationRow[];
}

export async function acceptApplication(applicationId: string) {
  const application = await getApplicationById(applicationId);
  if (!application) throw new Error("Solicitud no encontrada.");
  const job = await getJobById(application.job_id);
  if (!job) throw new Error("Trabajo no encontrado.");

  const updated = await updateStatus(applicationId, "ACCEPTED");
  await updateJobStatus(application.job_id, JobStatus.ASSIGNED);
  const clientAuthUserId = await getAuthUserIdByVoyUserId(job.creator_user_id);
  if (!clientAuthUserId) {
    throw new Error("No se pudo obtener el identificador del anunciante.");
  }
  await ensureChatForApplication({
    jobId: application.job_id,
    clientUserId: clientAuthUserId,
    helperUserId: application.helper_user_id,
    applicationId: application.id,
  });
  await rejectOtherApplications(application.job_id, applicationId);
  return updated;
}

export async function rejectApplication(applicationId: string) {
  return await updateStatus(applicationId, "REJECTED");
}

export async function cancelApplication(applicationId: string) {
  return await updateStatus(applicationId, "CANCELLED");
}

export async function markCompleted(applicationId: string) {
  const application = await getApplicationById(applicationId);
  if (!application) throw new Error("Solicitud no encontrada.");
  const updated = await updateStatus(applicationId, "COMPLETED");
  await updateJobStatus(application.job_id, JobStatus.COMPLETED);
  return updated;
}

export type ApplicationsService = {
  listByWorker: typeof listApplicationsByWorker;
  listByJob: typeof listByJob;
  getById: typeof getApplicationById;
  applyToJob: typeof applyToJob;
  acceptApplication: typeof acceptApplication;
  rejectApplication: typeof rejectApplication;
  cancelApplication: typeof cancelApplication;
  markCompleted: typeof markCompleted;
};

export const applicationsService: ApplicationsService = {
  listByWorker: listApplicationsByWorker,
  listByJob,
  getById: getApplicationById,
  applyToJob,
  acceptApplication,
  rejectApplication,
  cancelApplication,
  markCompleted,
};
