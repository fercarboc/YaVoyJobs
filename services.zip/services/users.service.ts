import { supabase } from "@/services/supabase";

export type UserMiniProfile = {
  id?: string;
  auth_user_id: string;
  full_name?: string | null;
  avatar_url?: string | null;
  city?: string | null;
  district?: string | null;
  verification_status?: string | null;
  role?: string | null;
};

const profileCache = new Map<string, UserMiniProfile>();
const voyToAuthCache = new Map<string, string>();

const fallbackProfile = (authUserId: string): UserMiniProfile => ({
  auth_user_id: authUserId,
  full_name: "Usuario",
  city: null,
  avatar_url: null,
  district: null,
  verification_status: null,
});

export async function getUserMiniProfile(authUserId: string): Promise<UserMiniProfile> {
  if (!authUserId) throw new Error("User ID requerido");
  const cached = profileCache.get(authUserId);
  if (cached) return cached;

  const { data, error } = await supabase
    .from("VoyUsers")
    .select("id, auth_user_id, full_name, avatar_url, city, district, verification_status, role")
    .eq("auth_user_id", authUserId)
    .maybeSingle();

  if (error) throw error;
  if (!data) {
    const fallback = fallbackProfile(authUserId);
    profileCache.set(authUserId, fallback);
    return fallback;
  }

  voyToAuthCache.set(data.id, data.auth_user_id);

  const profile: UserMiniProfile = {
    id: data.id,
    auth_user_id: data.auth_user_id,
    full_name: data.full_name,
    avatar_url: data.avatar_url,
    city: data.city,
    district: data.district,
    verification_status: data.verification_status,
    role: data.role ?? null,
  };

  profileCache.set(authUserId, profile);
  return profile;
}

export async function getAuthUserIdByVoyUserId(voyUserId: string): Promise<string | null> {
  if (!voyUserId) return null;
  if (voyToAuthCache.has(voyUserId)) return voyToAuthCache.get(voyUserId)!;

  const { data, error } = await supabase
    .from("VoyUsers")
    .select("auth_user_id")
    .eq("id", voyUserId)
    .maybeSingle();

  if (error) throw error;
  if (!data?.auth_user_id) return null;

  voyToAuthCache.set(voyUserId, data.auth_user_id);
  return data.auth_user_id;
}

export function clearUserMiniProfileCache(userId?: string) {
  if (userId) {
    profileCache.delete(userId);
  } else {
    profileCache.clear();
  }
}
