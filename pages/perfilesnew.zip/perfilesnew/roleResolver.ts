import { supabase } from "@/services/supabase";
import type { AuthState } from "@/types";

export type CanonicalRole = "ADMIN" | "HELPER" | "PARTICULAR" | "COMPANY" | "AGENCY" | "PROVIDER";

const LEGACY_ROLE_MAP: Record<string, CanonicalRole> = {
  ADMIN: "ADMIN",
  HELPER: "HELPER",
  PARTICULAR: "PARTICULAR",
  COMPANY: "COMPANY",
  AGENCY: "AGENCY",
  PROVIDER: "PROVIDER",
  WORKER: "HELPER",
  CLIENT: "PARTICULAR",
  REAL_ESTATE: "AGENCY",
  INMO: "AGENCY",
  MARKET_PROVIDER: "PROVIDER",
};

export function normalizeRole(input?: string | null): CanonicalRole | null {
  if (!input) return null;
  const key = input.toUpperCase();
  return LEGACY_ROLE_MAP[key] ?? null;
}

export async function resolveCanonicalRole(auth: AuthState): Promise<CanonicalRole | null> {
  const sources = [
    (auth as any).voyUser?.role,
    (auth as any).profile?.role,
    auth.user?.role,
    (auth as any).role,
  ];

  for (const candidate of sources) {
    const normalized = normalizeRole(typeof candidate === "string" ? candidate : null);
    if (normalized) {
      return normalized;
    }
  }

  const authUserId = auth.user?.id;
  if (!authUserId) return null;

  try {
    const { data, error } = await supabase
      .from("VoyUsers")
      .select("role")
      .eq("auth_user_id", authUserId)
      .maybeSingle();

    if (error) {
      console.error("[roleResolver] error loading role from VoyUsers", error);
      return null;
    }

    return normalizeRole(data?.role ?? null);
  } catch (err) {
    console.error("[roleResolver] failed to resolve role", err);
    return null;
  }
}
