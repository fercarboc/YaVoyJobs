import React, { useEffect, useMemo, useState } from "react";
import type { AuthState } from "@/types";
import { Layout, LayoutMenuItem } from "./components/Layout";
import ProfileOverview from "./components/ProfileOverview";
import { WorkerDashboard } from "./components/worker/WorkerDashboard";
import { WorkerSearchView } from "./components/worker/WorkerSearchView";
import { WorkerApplicationsView } from "./components/worker/WorkerApplicationsView";
import { ChatComponent } from "./components/ChatComponent";
import { PaymentsView } from "./components/PaymentsView";
import { RealEstateBusinessView } from "./components/RealEstateBusinessView";
import { PlansView } from "./components/PlansView";
import InvoicesView from "./components/InvoicesView";
import ClientHome from "./roles/client/ClientHome";
import CompanyHome from "./roles/company/CompanyHome";
import AgencyHome from "./roles/agency/AgencyHome";
import ProviderHome from "./roles/provider/ProviderHome";
import AdminHome from "./roles/admin/AdminHome";
import { resolveCanonicalRole, CanonicalRole } from "./roleResolver";
import { UserRole, User, Candidate } from "./types";

const DEFAULT_ROLE: CanonicalRole = "PARTICULAR";

const ROLE_LABELS: Record<CanonicalRole, string> = {
  PARTICULAR: "Cliente YaVoy",
  COMPANY: "Empresa YaVoy",
  HELPER: "Trabajador YaVoy",
  AGENCY: "Agencia YaVoy",
  PROVIDER: "Proveedor YaVoy",
  ADMIN: "Administrador YaVoy",
};

const ROLE_HOME_COMPONENTS: Record<CanonicalRole, React.FC> = {
  PARTICULAR: ClientHome,
  COMPANY: CompanyHome,
  HELPER: WorkerDashboard,
  AGENCY: AgencyHome,
  PROVIDER: ProviderHome,
  ADMIN: AdminHome,
};

const ROLE_MENUS: Record<CanonicalRole, LayoutMenuItem[]> = {
  PARTICULAR: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "ads", label: "Mis anuncios", view: "ads" },
    { id: "candidates", label: "Candidatos", view: "candidates" },
    { id: "publish", label: "Publicar", view: "publish" },
    { id: "messages", label: "Mensajes", view: "messages" },
    { id: "payments", label: "Pagos", view: "payments" },
    { id: "profile", label: "Perfil", view: "profile" },
  ],
  COMPANY: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "ads", label: "Mis anuncios", view: "ads" },
    { id: "candidates", label: "Candidatos", view: "candidates" },
    { id: "publish", label: "Publicar", view: "publish" },
    { id: "messages", label: "Mensajes", view: "messages" },
    { id: "payments", label: "Pagos", view: "payments" },
    { id: "profile", label: "Perfil", view: "profile" },
  ],
  HELPER: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "search", label: "Buscar", view: "search" },
    { id: "applications", label: "Mis Postulaciones", view: "applications" },
    { id: "realestate", label: "Inmo y Negocios", view: "realestate" },
    { id: "messages", label: "Mensajes", view: "messages" },
    { id: "payments", label: "Pagos", view: "payments" },
    { id: "profile", label: "Perfil", view: "profile" },
  ],
  AGENCY: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "realestate", label: "Anuncios Inmobiliarios", view: "realestate" },
    { id: "schedule", label: "Visitas / Agenda", view: "schedule" },
    { id: "candidates", label: "Candidatos", view: "candidates" },
    { id: "messages", label: "Mensajes", view: "messages" },
    { id: "payments", label: "Pagos", view: "payments" },
    { id: "profile", label: "Perfil", view: "profile" },
  ],
  PROVIDER: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "catalog", label: "Catálogo", view: "catalog" },
    { id: "orders", label: "Pedidos", view: "orders" },
    { id: "clients", label: "Clientes", view: "clients" },
    { id: "incidents", label: "Incidencias", view: "incidents" },
    { id: "marketing", label: "Publicidad", view: "marketing" },
    { id: "messages", label: "Mensajes", view: "messages" },
    { id: "payments", label: "Pagos", view: "payments" },
    { id: "invoices", label: "Facturas", view: "invoices" },
    { id: "plans", label: "Planes", view: "plans" },
    { id: "profile", label: "Perfil", view: "profile" },
  ],
  ADMIN: [
    { id: "home", label: "Inicio", view: "home" },
    { id: "audit", label: "Auditoría", view: "audit" },
    { id: "support", label: "Soporte", view: "support" },
  ],
};

const VIEW_DESCRIPTIONS: Record<string, { title: string; description: string }> = {
  ads: {
    title: "Mis anuncios",
    description: "Aquí controlarás el estado de cada publicación, pero por ahora sólo se muestra el resumen.",
  },
  candidates: {
    title: "Candidatos",
    description: "Cuando conectemos con Supabase verás las candidaturas y podrás gestionarlas desde aquí.",
  },
  publish: {
    title: "Publicar",
    description: "Formulario de nuevos anuncios listo para conectar con el backend en la siguiente fase.",
  },
  search: {
    title: "Buscar",
    description: "Explora trabajos y ofertas cercanas para postularte.",
  },
  applications: {
    title: "Mis Postulaciones",
    description: "Listado de postulaciones con sus estados actualizados en tiempo real.",
  },
  realestate: {
    title: "Inmo y Negocios",
    description: "Sección dedicada a inmuebles y negocios, pendiente de aterrizar en producción.",
  },
  schedule: {
    title: "Visitas / Agenda",
    description: "Agenda citas y visitas con clientes y candidatos desde aquí.",
  },
  messages: {
    title: "Mensajes",
    description: "Todos los chats aparecerán en esta sección una vez activemos la suscripción.",
  },
  payments: {
    title: "Pagos",
    description: "Movimientos, comprobantes y facturas listos para conectar con servicios financieros.",
  },
  catalog: {
    title: "Catálogo",
    description: "Gestiona tu catálogo de productos y servicios del marketplace.",
  },
  orders: {
    title: "Pedidos",
    description: "Resumen de pedidos y entregas para el proveedor.",
  },
  clients: {
    title: "Clientes",
    description: "Lista de cuentas comerciales que interactúan con tu catálogo.",
  },
  incidents: {
    title: "Incidencias",
    description: "Reportes y devoluciones en cola de atención.",
  },
  marketing: {
    title: "Publicidad",
    description: "Campañas activas y sugerencias para ampliar visibilidad.",
  },
  invoices: {
    title: "Facturas",
    description: "Facturación completa una vez carguemos los documentos.",
  },
  plans: {
    title: "Planes",
    description: "Gestión de planes y suscripciones para todos los roles.",
  },
  audit: {
    title: "Auditoría",
    description: "Información administrativa para el equipo de YaVoy.",
  },
  support: {
    title: "Soporte",
    description: "Historias de incidencias, tickets abiertos y respuestas.",
  },
  profile: {
    title: "Perfil",
    description: "Sólo aquí se muestra tu información personal completa.",
  },
};

const ViewPlaceholder: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <section className="space-y-3 rounded-2xl bg-white p-6 shadow-sm border border-slate-100">
    <p className="text-sm uppercase tracking-[0.4em] text-slate-400">Próximamente</p>
    <h2 className="text-2xl font-semibold text-slate-900">{title}</h2>
    <p className="text-sm text-slate-500">{description}</p>
  </section>
);

type ProfileRouterProps = {
  auth: AuthState;
};

type ChatContext = {
  jobTitle: string;
  otherName: string;
} | null;

const canonicalToUserRole = (role: CanonicalRole | null): UserRole => {
  switch (role) {
    case "ADMIN":
      return UserRole.ADMIN;
    case "HELPER":
      return UserRole.WORKER;
    case "PARTICULAR":
      return UserRole.CLIENT;
    case "COMPANY":
      return UserRole.COMPANY;
    case "AGENCY":
      return UserRole.AGENCY;
    case "PROVIDER":
      return UserRole.PROVIDER;
    default:
      return UserRole.CLIENT;
  }
};

const ProfileRouter: React.FC<ProfileRouterProps> = ({ auth }) => {
  const [resolvedRole, setResolvedRole] = useState<CanonicalRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState("home");
  const [chatContext, setChatContext] = useState<ChatContext>(null);

  useEffect(() => {
    let canceled = false;
    setLoading(true);

    resolveCanonicalRole(auth)
      .then((role) => {
        if (canceled) return;
        const nextRole = role ?? DEFAULT_ROLE;
        setResolvedRole(nextRole);
        setActiveView("home");
      })
      .catch(() => {
        if (canceled) return;
        setResolvedRole(DEFAULT_ROLE);
        setActiveView("home");
      })
      .finally(() => {
        if (!canceled) setLoading(false);
      });

    return () => {
      canceled = true;
    };
  }, [auth]);

  const canonicalRole = resolvedRole ?? DEFAULT_ROLE;
  const menuItems = ROLE_MENUS[canonicalRole] ?? ROLE_MENUS[DEFAULT_ROLE];
  const roleLabel = ROLE_LABELS[canonicalRole] ?? ROLE_LABELS[DEFAULT_ROLE];
  const HomeComponent = ROLE_HOME_COMPONENTS[canonicalRole] ?? ROLE_HOME_COMPONENTS[DEFAULT_ROLE];
  const userRole = canonicalToUserRole(canonicalRole);

  const workerUser = useMemo<User>(() => {
    const name = auth.user?.full_name ?? auth.user?.email ?? "Usuario YaVoy";
    return {
      id: auth.user?.id ?? "guest",
      name,
      avatar: auth.user?.avatar_url ?? auth.user?.selfie_photo_url ?? "",
      role: userRole,
      city: auth.user?.city ?? "Madrid",
      rating: 4.9,
      isVerified: auth.user?.verification_status === "VERIFIED",
    };
  }, [auth.user, userRole]);

  const handleSearchJobs = () => setActiveView("search");

  const handleOpenChat = (application: Candidate) => {
    setChatContext({ jobTitle: application.jobTitle, otherName: application.employerName });
    setActiveView("messages");
  };

  const renderWorkerContent = () => {
    switch (activeView) {
      case "home":
        return <WorkerDashboard user={workerUser} onViewProfile={() => setActiveView("profile")} onSearchJobs={handleSearchJobs} />;
      case "search":
        return (
          <WorkerSearchView
            onApply={() => setActiveView("applications")}
            onViewJob={() => setActiveView("applications")}
          />
        );
      case "applications":
        return <WorkerApplicationsView user={workerUser} onOpenChat={handleOpenChat} />;
      case "realestate":
        return (
          <RealEstateBusinessView
            hasInmoPlan
            hasNegocioPlan
            role={UserRole.WORKER}
            adCount={3}
            adLimit={10}
            onGoToPlans={() => setActiveView("plans")}
          />
        );
      case "messages":
        return chatContext ? (
          <ChatComponent jobTitle={chatContext.jobTitle} otherName={chatContext.otherName} />
        ) : (
          <ViewPlaceholder
            title="Mensajes"
            description="Selecciona una postulación aceptada o inicia un chat desde Mis Postulaciones."
          />
        );
      case "payments":
        return <PaymentsView role={UserRole.WORKER} />;
      case "profile":
        return <ProfileOverview user={auth.user} />;
      default:
        return <WorkerDashboard user={workerUser} onViewProfile={() => setActiveView("profile")} onSearchJobs={handleSearchJobs} />;
    }
  };

  const activeContent = useMemo(() => {
    if (canonicalRole === "HELPER") {
      return renderWorkerContent();
    }

    if (activeView === "home") {
      return <HomeComponent />;
    }

    if (activeView === "profile") {
      return <ProfileOverview user={auth.user} />;
    }

    const descriptor = VIEW_DESCRIPTIONS[activeView] ?? {
      title: "Vista en construcción",
      description: "Estamos preparando esta sección para ti.",
    };

    return <ViewPlaceholder title={descriptor.title} description={descriptor.description} />;
  }, [activeView, canonicalRole, HomeComponent, auth.user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <p className="text-lg font-semibold text-slate-900">Cargando tu rol...</p>
      </div>
    );
  }

  return (
    <Layout roleLabel={roleLabel} menuItems={menuItems} activeView={activeView} onMenuSelect={setActiveView}>
      {activeContent}
    </Layout>
  );
};

export default ProfileRouter;
