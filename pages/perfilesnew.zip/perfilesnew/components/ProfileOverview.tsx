import React from "react";

type ProfileOverviewProps = {
  user: {
    full_name?: string;
    email?: string;
    city?: string;
    role?: string;
  } | null;
};

const ProfileOverview: React.FC<ProfileOverviewProps> = ({ user }) => {
  const name = user?.full_name ?? user?.email ?? "Usuario YaVoy";
  const email = user?.email ?? "Sin correo asignado";
  const location = user?.city ?? "Ciudad pendiente";
  const role = user?.role ?? "Rol sin definir";

  return (
    <section className="space-y-6 rounded-3xl bg-white p-6 shadow-sm border border-slate-100">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.4em] text-slate-400">Perfil</p>
          <h2 className="text-3xl font-semibold text-slate-900">{name}</h2>
          <p className="text-sm text-slate-500">{email}</p>
        </div>
        <div className="w-16 h-16 rounded-2xl bg-slate-200 flex items-center justify-center text-slate-600 font-semibold text-lg">
          {name.charAt(0)}
        </div>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-1">
          <p className="text-xs font-semibold uppercase tracking-[0.4em] text-slate-400">Ubicación</p>
          <p className="text-sm font-medium text-slate-700">{location}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs font-semibold uppercase tracking-[0.4em] text-slate-400">Rol</p>
          <p className="text-sm font-medium text-slate-700">{role}</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs font-semibold uppercase tracking-[0.4em] text-slate-400">Seguridad</p>
          <p className="text-sm font-medium text-emerald-600">Cuenta verificada</p>
        </div>
      </div>
      <div className="space-y-3">
        <button className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-left text-sm font-semibold text-slate-700 hover:bg-slate-50 transition">
          Datos personales
        </button>
        <button className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-left text-sm font-semibold text-slate-700 hover:bg-slate-50 transition">
          Seguridad y notificaciones
        </button>
        <button className="w-full rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-left text-sm font-semibold text-red-600 hover:bg-red-100 transition">
          Cerrar sesión
        </button>
      </div>
    </section>
  );
};

export default ProfileOverview;
