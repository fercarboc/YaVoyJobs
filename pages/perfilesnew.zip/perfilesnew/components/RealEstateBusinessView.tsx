
import React, { useState, useEffect } from 'react';
import { AdType, AdStatus, RealEstateOperation, RealEstateCategory, UserRole } from '../types';
import { ICONS } from '../constants';
import { AdCreateForm } from './AdCreateForm';

interface RealEstateBusinessViewProps {
  hasInmoPlan: boolean;
  hasNegocioPlan: boolean;
  onGoToPlans: () => void;
  role?: UserRole;
  adCount?: number;
  adLimit?: number;
  forceTab?: 'inmo' | 'negocios';
}

export const RealEstateBusinessView: React.FC<RealEstateBusinessViewProps> = ({ 
  hasInmoPlan, 
  hasNegocioPlan,
  onGoToPlans,
  role,
  adCount = 0,
  adLimit = 0,
  forceTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'inmo' | 'negocios'>(forceTab || 'inmo');
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => {
    if (forceTab) setActiveSubTab(forceTab);
  }, [forceTab]);

  const MOCK_ADS = [
    { id: 'r1', type: AdType.REAL_STATE, title: 'Piso luminoso en Malasaña', location: 'Madrid', price: 1200, status: AdStatus.AVAILABLE, operation: RealEstateOperation.RENT, realEstateCategory: RealEstateCategory.FLAT, surface: 65, leads: 12 },
    { id: 'b1', type: AdType.BUSINESS, title: 'Traspaso Bar Cafetería', location: 'Barcelona', price: 45000, status: AdStatus.NEGOTIATING, sector: 'Bar / Cafetería', surface: 40, monthlyRent: 1500, leads: 4 },
    { id: 'r2', type: AdType.REAL_STATE, title: 'Local comercial Gran Vía', location: 'Madrid', price: 250000, status: AdStatus.RESERVED, operation: RealEstateOperation.SALE, realEstateCategory: RealEstateCategory.LOCAL, surface: 110, leads: 0 },
  ];

  const filteredAds = MOCK_ADS.filter(ad => 
    activeSubTab === 'inmo' ? ad.type === AdType.REAL_STATE : ad.type === AdType.BUSINESS
  );

  const isCurrentTabLocked = (activeSubTab === 'inmo' && !hasInmoPlan) || (activeSubTab === 'negocios' && !hasNegocioPlan);

  if (showCreate) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => setShowCreate(false)}
            className="flex items-center gap-2 text-sm font-bold text-gray-400 hover:text-gray-600 transition-colors"
          >
            {ICONS.Chevron} Volver al panel
          </button>
        </div>
        <AdCreateForm initialType={activeSubTab === 'inmo' ? AdType.REAL_STATE : AdType.BUSINESS} onSuccess={() => setShowCreate(false)} />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-3xl font-bold text-gray-900 tracking-tight">
              {activeSubTab === 'inmo' ? 'Inmobiliaria' : 'Negocios'}
            </h2>
          </div>
          <p className="text-gray-500">
            {activeSubTab === 'inmo' 
              ? 'Gestiona tus anuncios de inmuebles (pisos, locales, habitaciones)' 
              : 'Gestiona tus anuncios de venta y traspaso de negocios'}
          </p>
        </div>
        {!isCurrentTabLocked && role !== UserRole.WORKER && (
          <button 
            onClick={() => setShowCreate(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2"
          >
            {ICONS.Add} Publicar {activeSubTab === 'inmo' ? 'inmueble' : 'negocio'}
          </button>
        )}
      </div>

      {!forceTab && (
        <div className="flex p-1 bg-gray-100 rounded-2xl w-full max-w-md">
          <button 
            onClick={() => setActiveSubTab('inmo')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all relative ${activeSubTab === 'inmo' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {ICONS.RealEstate} Inmobiliaria
            {!hasInmoPlan && <div className="absolute top-1 right-1 text-amber-500">{ICONS.Lock}</div>}
          </button>
          <button 
            onClick={() => setActiveSubTab('negocios')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all relative ${activeSubTab === 'negocios' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {ICONS.Business} Negocios
            {!hasNegocioPlan && <div className="absolute top-1 right-1 text-amber-500">{ICONS.Lock}</div>}
          </button>
        </div>
      )}

      {isCurrentTabLocked ? (
        <div className="bg-white border border-gray-100 rounded-[2.5rem] p-12 flex flex-col items-center justify-center text-center shadow-sm animate-in zoom-in-95 duration-500">
          <div className="w-24 h-24 bg-blue-50 text-blue-300 rounded-[2rem] flex items-center justify-center mb-6 relative">
            <div className="scale-150">{activeSubTab === 'inmo' ? ICONS.RealEstate : ICONS.Business}</div>
            <div className="absolute -top-1 -right-1 bg-white p-2 rounded-full shadow-lg text-amber-500 border border-gray-100">
              {ICONS.Lock}
            </div>
          </div>
          <h3 className="text-2xl font-black text-gray-900 mb-3">
            Módulo de {activeSubTab === 'inmo' ? 'Inmobiliaria' : 'Negocios'} para Colaboradores
          </h3>
          <p className="text-gray-500 max-w-md mb-8 leading-relaxed">
            Como Colaborador, necesitas activar el plan específico para acceder a este mercado exclusivo y contactar con agencias o propietarios.
          </p>
          <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl mb-8 w-full max-w-sm">
             <div className="flex items-center gap-3 mb-2">
                <span className="text-blue-600">{ICONS.Check}</span>
                <p className="text-sm font-bold text-blue-900 text-left">Contacta con agencias directamente</p>
             </div>
             <div className="flex items-center gap-3">
                <span className="text-blue-600">{ICONS.Check}</span>
                <p className="text-sm font-bold text-blue-900 text-left">Acceso a traspasos de negocios</p>
             </div>
          </div>
          <button 
            onClick={onGoToPlans}
            className="bg-blue-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 flex items-center gap-3"
          >
            {ICONS.Plans} Ver Planes Colaborador
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAds.map(ad => (
            <div key={ad.id} className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-all group border-b-4 border-b-blue-500">
              <div className="h-40 bg-gray-200 relative overflow-hidden">
                 <img src={`https://picsum.photos/400/300?random=${ad.id}`} alt={ad.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                 <div className="absolute top-3 left-3 flex gap-2">
                   <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-widest ${
                     ad.status === AdStatus.AVAILABLE ? 'bg-emerald-500 text-white' : 
                     ad.status === AdStatus.RESERVED ? 'bg-amber-500 text-white' : 'bg-gray-500 text-white'
                   }`}>
                     {ad.status}
                   </span>
                   {ad.operation && (
                     <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-widest">
                       {ad.operation === RealEstateOperation.RENT ? 'Alquiler' : 'Venta'}
                     </span>
                   )}
                 </div>
              </div>
              <div className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors leading-tight">{ad.title}</h3>
                  <p className="text-lg font-black text-gray-900">{ad.price.toLocaleString()}€{ad.operation === RealEstateOperation.RENT && '/mes'}</p>
                </div>
                <p className="text-xs text-gray-500 flex items-center gap-1 mb-4">
                  {ICONS.Location} {ad.location} • {ad.surface}m²
                </p>
                <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                  <div className="flex items-center gap-1 text-xs font-bold text-blue-600">
                    {ICONS.Messages} {ad.leads} interesados
                  </div>
                  <button className="text-sm font-bold text-gray-400 hover:text-gray-900 flex items-center gap-1">
                    Ver más {ICONS.Chevron}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
