
import React, { useState } from 'react';
import { AdType, RealEstateOperation, RealEstateCategory, AdStatus } from '../types';
import { ICONS } from '../constants';
import { optimizeJobDescription } from '../../../services/geminiService';

interface AdCreateFormProps {
  initialType: AdType;
  onSuccess: () => void;
}

export const AdCreateForm: React.FC<AdCreateFormProps> = ({ initialType, onSuccess }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    type: initialType,
    title: '',
    description: '',
    location: '',
    price: '',
    // Real Estate
    operation: RealEstateOperation.RENT,
    realEstateCategory: RealEstateCategory.FLAT,
    surface: '',
    availableFrom: '',
    // Business
    sector: 'Restaurante',
    monthlyRent: ''
  });

  const handleNext = () => setStep(step + 1);
  const handleBack = () => setStep(step - 1);

  const handleOptimize = async () => {
    if (!formData.title || !formData.description) return;
    setLoading(true);
    const optimized = await optimizeJobDescription(formData.title, formData.description);
    setFormData({ ...formData, description: optimized || formData.description });
    setLoading(false);
  };

  const sectors = ['Restaurante', 'Bar / Cafetería', 'Oficina', 'Taller', 'Farmacia', 'Inmobiliaria', 'Tienda de ropa', 'Comercio minorista', 'Otros'];

  return (
    <div className="bg-white rounded-3xl border border-gray-100 p-6 md:p-8 shadow-sm max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            {formData.type === AdType.REAL_STATE ? 'Publicar Inmueble' : 'Traspasar Negocio'}
          </h2>
          <p className="text-sm text-gray-500">Paso {step} de 3</p>
        </div>
        <div className="flex gap-1.5">
          {[1, 2, 3].map(i => (
            <div key={i} className={`h-1.5 w-8 rounded-full transition-all ${step >= i ? 'bg-blue-600' : 'bg-gray-100'}`}></div>
          ))}
        </div>
      </div>

      {step === 1 && (
        <div className="space-y-6">
          {formData.type === AdType.REAL_STATE ? (
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => setFormData({...formData, operation: RealEstateOperation.RENT})}
                className={`p-4 rounded-xl border-2 text-center font-bold transition-all ${formData.operation === RealEstateOperation.RENT ? 'border-blue-600 bg-blue-50/50 text-blue-600' : 'border-gray-100'}`}
              >
                Alquiler
              </button>
              <button 
                onClick={() => setFormData({...formData, operation: RealEstateOperation.SALE})}
                className={`p-4 rounded-xl border-2 text-center font-bold transition-all ${formData.operation === RealEstateOperation.SALE ? 'border-blue-600 bg-blue-50/50 text-blue-600' : 'border-gray-100'}`}
              >
                Venta
              </button>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Sector del negocio</label>
              <select 
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white font-medium"
                value={formData.sector}
                onChange={(e) => setFormData({...formData, sector: e.target.value})}
              >
                {sectors.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Título del anuncio</label>
            <input 
              type="text" 
              placeholder={formData.type === AdType.REAL_STATE ? "Ej: Piso acogedor en Calle Mayor" : "Ej: Traspaso de pizzería equipada"}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-600/20"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Precio (€)</label>
              <input 
                type="number" 
                placeholder="0.00"
                className="w-full px-4 py-3 rounded-xl border border-gray-200"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Ubicación / Zona</label>
              <input 
                type="text" 
                placeholder="Ciudad o Barrio"
                className="w-full px-4 py-3 rounded-xl border border-gray-200"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
              />
            </div>
          </div>

          <button onClick={handleNext} className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/10">Continuar</button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-semibold text-gray-700">Descripción</label>
              <button 
                onClick={handleOptimize}
                disabled={loading || !formData.title}
                className="text-xs font-bold text-blue-600 flex items-center gap-1"
              >
                {loading ? 'Optimizando...' : 'Mejorar con IA ✨'}
              </button>
            </div>
            <textarea 
              rows={5}
              placeholder="Describe las características principales, estado, equipamiento..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Superficie (m²)</label>
              <input 
                type="number" 
                className="w-full px-4 py-3 rounded-xl border border-gray-200"
                value={formData.surface}
                onChange={(e) => setFormData({...formData, surface: e.target.value})}
              />
            </div>
            {formData.type === AdType.REAL_STATE ? (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Disponible desde</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl border border-gray-200"
                  value={formData.availableFrom}
                  onChange={(e) => setFormData({...formData, availableFrom: e.target.value})}
                />
              </div>
            ) : (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Alquiler mensual local (€)</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 rounded-xl border border-gray-200"
                  value={formData.monthlyRent}
                  onChange={(e) => setFormData({...formData, monthlyRent: e.target.value})}
                />
              </div>
            )}
          </div>

          <div className="flex gap-4">
            <button onClick={handleBack} className="flex-1 bg-gray-50 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-100">Atrás</button>
            <button onClick={handleNext} className="flex-[2] bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/10">Siguiente</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-200 rounded-3xl p-12 text-center">
             <div className="flex justify-center mb-4 text-gray-300">{ICONS.Invoices}</div>
             <p className="text-sm font-bold text-gray-500 mb-2">Añadir fotos del inmueble/negocio</p>
             <p className="text-xs text-gray-400">Arrastra archivos o haz clic para subir</p>
             <input type="file" multiple className="hidden" />
          </div>

          <div className="bg-blue-50 p-6 rounded-2xl space-y-3">
             <h4 className="font-bold text-blue-900 text-center">Resumen del Anuncio</h4>
             <div className="flex justify-between text-sm">
                <span className="text-blue-700/60">Operación</span>
                <span className="font-bold text-blue-900 uppercase">{formData.type}</span>
             </div>
             <div className="flex justify-between text-sm">
                <span className="text-blue-700/60">Precio</span>
                <span className="font-bold text-blue-900">{formData.price}€</span>
             </div>
             <div className="pt-2 border-t border-blue-200 text-[10px] text-blue-600 font-bold uppercase tracking-wider text-center">
                Pago por anuncio o incluido en tu plan activo
             </div>
          </div>

          <div className="flex gap-4">
            <button onClick={handleBack} className="flex-1 bg-gray-50 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-100">Atrás</button>
            <button onClick={onSuccess} className="flex-[2] bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/10">Publicar anuncio</button>
          </div>
        </div>
      )}
    </div>
  );
};
