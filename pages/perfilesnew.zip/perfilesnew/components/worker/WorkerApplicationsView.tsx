
import React, { useState, useEffect } from 'react';
import { ICONS, mockWorkerApplications } from '../../constants';
import { JobStatus, Candidate, User } from '../../types';
import { applicationsService } from '../../../../services/applications.service';

interface WorkerApplicationsViewProps {
  user: User;
  onOpenChat: (application: Candidate) => void;
}

export const WorkerApplicationsView: React.FC<WorkerApplicationsViewProps> = ({ user, onOpenChat }) => {
  const [activeTab, setActiveTab] = useState<'ACTIVA' | 'ACEPTADA' | 'RECHAZADA' | 'CERRADA'>('ACTIVA');
  const [applications, setApplications] = useState<Candidate[]>(mockWorkerApplications);

  // Escuchador de cambios Realtime
  useEffect(() => {
    const unsubscribe = applicationsService.subscribeToChanges((event) => {
      if (event.type === 'JOB_UPDATE') {
        const { jobId, acceptedApplicationId, newStatus } = event.payload;

        setApplications(prev => prev.map(app => {
          // Si la postulación pertenece al anuncio que ha sido actualizado
          if (app.jobId === jobId) {
            // Caso: Yo soy el aceptado (JOB_ACCEPTED)
            if (app.id === acceptedApplicationId) {
              return { 
                ...app, 
                status: 'ACCEPTED' as const, 
                jobStatus: JobStatus.IN_PROGRESS 
              };
            }
            // Caso: Se ha aceptado a otro (JOB_REJECTED para mí)
            return { 
              ...app, 
              status: 'REJECTED' as const, 
              jobStatus: JobStatus.IN_PROGRESS 
            };
          }
          return app;
        }));
      }
    });

    // Fix: Ensure the cleanup function returns void to comply with React's EffectCallback type.
    return () => { unsubscribe(); };
  }, []);

  const filteredApplications = applications.filter(app => {
    if (activeTab === 'ACTIVA') return app.status === 'PENDING' && app.jobStatus === JobStatus.OPEN;
    if (activeTab === 'ACEPTADA') return app.status === 'ACCEPTED';
    if (activeTab === 'RECHAZADA') return app.status === 'REJECTED';
    if (activeTab === 'CERRADA') return app.jobStatus === JobStatus.CLOSED || app.jobStatus === JobStatus.COMPLETED;
    return false;
  });

  const getStatusChip = (app: Candidate) => {
    switch (app.status) {
      case 'ACCEPTED': return (
        <span className="bg-emerald-50 text-emerald-600 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest ring-1 ring-emerald-200 shadow-sm animate-in zoom-in-50">
          ¡CONTRATADO!
        </span>
      );
      case 'REJECTED': return (
        <span className="bg-gray-100 text-gray-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
          No seleccionado
        </span>
      );
      case 'PENDING': return (
        <span className="bg-blue-50 text-blue-600 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-blue-100">
          En revisión
        </span>
      );
      default: return null;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Mis Postulaciones</h2>
          <p className="text-gray-500 mt-1">Sigue el estado de tus solicitudes en tiempo real</p>
        </div>
      </div>

      <div className="flex p-1 bg-gray-100 rounded-2xl w-full max-w-2xl overflow-x-auto">
        {(['ACTIVA', 'ACEPTADA', 'RECHAZADA', 'CERRADA'] as const).map((tab) => {
          const count = applications.filter(app => {
            if (tab === 'ACTIVA') return app.status === 'PENDING' && app.jobStatus === JobStatus.OPEN;
            if (tab === 'ACEPTADA') return app.status === 'ACCEPTED';
            if (tab === 'RECHAZADA') return app.status === 'REJECTED';
            if (tab === 'CERRADA') return app.jobStatus === JobStatus.CLOSED || app.jobStatus === JobStatus.COMPLETED;
            return false;
          }).length;

          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 min-w-[120px] py-3.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                activeTab === tab ? 'bg-white text-blue-600 shadow-sm ring-1 ring-gray-200' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.charAt(0) + tab.slice(1).toLowerCase()}
              {count > 0 && <span className={`w-5 h-5 rounded-full text-[9px] flex items-center justify-center font-black ${activeTab === tab ? 'bg-blue-600 text-white shadow-sm' : 'bg-gray-200 text-gray-400'}`}>{count}</span>}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredApplications.length > 0 ? (
          filteredApplications.map(app => (
            <div 
              key={app.id} 
              className={`bg-white rounded-[2.5rem] border p-8 shadow-sm hover:shadow-md transition-all relative overflow-hidden group animate-in slide-in-from-bottom-4 duration-500 ${
                app.status === 'ACCEPTED' ? 'border-emerald-200 ring-2 ring-emerald-500/5' : 'border-gray-100'
              }`}
            >
              {app.status === 'ACCEPTED' && (
                <div className="absolute top-0 right-0 bg-emerald-500 text-white text-[8px] font-black px-4 py-1.5 rounded-bl-xl uppercase tracking-widest animate-pulse">
                  CONTRATADO
                </div>
              )}
              
              <div className="flex justify-between items-start mb-6">
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    {getStatusChip(app)}
                  </div>
                  <h3 className="text-xl font-black text-gray-900 leading-tight group-hover:text-blue-600 transition-colors">
                    {app.jobTitle}
                  </h3>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-gray-900">{app.jobBudget}€</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Precio acordado</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                 <div className="flex items-center gap-3 bg-gray-50/50 p-3 rounded-2xl border border-gray-50">
                    <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center text-blue-600">
                       {ICONS.Profile}
                    </div>
                    <div className="min-w-0">
                       <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest leading-none mb-1">Empleador</p>
                       <p className="text-sm font-bold text-gray-700 truncate">{app.employerName}</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-6 text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">
                    <span className="flex items-center gap-1.5">{ICONS.Location} {app.jobLocation}</span>
                    <span className="flex items-center gap-1.5">{ICONS.Calendar} Solicitado: {app.appliedAt}</span>
                 </div>
              </div>

              <div className="flex gap-3">
                 <button className="flex-1 bg-gray-50 text-gray-600 py-4 rounded-2xl text-xs font-bold hover:bg-gray-100 transition-colors border border-gray-100">
                    Ver anuncio
                 </button>
                 {app.status === 'ACCEPTED' ? (
                   <button 
                     onClick={() => onOpenChat(app)}
                     className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl text-xs font-bold shadow-xl shadow-blue-600/30 hover:bg-blue-700 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
                   >
                      {ICONS.Messages} Contactar con Cliente
                   </button>
                 ) : (
                   <button 
                     disabled={app.status === 'REJECTED'}
                     className={`flex-[2] py-4 rounded-2xl text-xs font-bold transition-all ${
                       app.status === 'REJECTED' 
                         ? 'bg-gray-50 text-gray-300 cursor-not-allowed border border-gray-100' 
                         : 'bg-white text-blue-600 border border-blue-100 hover:bg-blue-50'
                     }`}
                   >
                      Esperando respuesta
                   </button>
                 )}
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-24 text-center bg-white rounded-[3rem] border-2 border-dashed border-gray-100 shadow-inner">
             <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-200">
                {ICONS.List}
             </div>
             <h3 className="text-gray-400 font-black text-xl">Sin postulaciones en esta sección</h3>
             <p className="text-gray-400 text-sm mt-2 max-w-sm mx-auto leading-relaxed">
               Las actualizaciones automáticas aparecerán aquí cuando los empleadores revisen tu perfil.
             </p>
          </div>
        )}
      </div>
    </div>
  );
};
