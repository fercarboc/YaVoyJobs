import React from "react";
import { JobCard } from "../JobCard";
import { mockParticularJobs } from "../../constants";
import { UserRole } from "../../types";

interface WorkerSearchViewProps {
  onApply: (jobId: string) => void;
  onViewJob?: (jobId: string) => void;
}

export const WorkerSearchView: React.FC<WorkerSearchViewProps> = ({ onApply, onViewJob }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 tracking-tight">Oportunidades cerca</h2>
          <p className="text-sm text-gray-500">Explora los microempleos más recientes y postúlate con un clic.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:border-gray-300 transition-colors">
            Filtrar zona
          </button>
          <button className="px-4 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:border-gray-300 transition-colors">
            Guardar búsqueda
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockParticularJobs.map((job) => (
          <JobCard
            key={job.id}
            job={job}
            role={UserRole.WORKER}
            onView={(id) => onViewJob?.(id)}
            onApply={(id) => onApply(id)}
          />
        ))}
      </div>
    </div>
  );
};
