import { 
  Menu, X, Heart, Smartphone, ShoppingCart, 
  User, Briefcase, Building, LogIn, CheckCircle, 
  MapPin, Clock, Euro, ArrowRight, Star, Shield,
  LayoutDashboard, Sparkles, Download,
  PawPrint, Hammer, Lightbulb, MessageCircle,
  Navigation, UserCheck, Search, Edit3,
  Quote, Users, Trash, ChevronDown, FileText
} from 'lucide-react';

export const Icons = {
  Menu, X, Heart, Smartphone, ShoppingCart, 
  User, Briefcase, Building, LogIn, CheckCircle, 
  MapPin, Clock, Euro, ArrowRight, Star, Shield,
  LayoutDashboard, Sparkles, Download,
  PawPrint, Hammer, Lightbulb, MessageCircle,
  Navigation, UserCheck, Search, Edit3,
  Quote, Users, Trash, ChevronDown, FileText
};