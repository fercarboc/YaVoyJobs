// App.tsx
import React, { useEffect, useState } from "react";
import { HashRouter } from "react-router-dom";
import { supabase } from "./services/supabase";
import { Layout } from "./components/Layout";
import AppRoutes from "./components/routing/AppRoutes";
import type { AuthState } from "./types";

const INITIAL_AUTH: AuthState = {
  isAuthenticated: false,
  user: null,
  loading: true,
};

export default function App() {
  const [auth, setAuth] = useState<AuthState>(INITIAL_AUTH);

  useEffect(() => {
    console.log("[APP BOOT]");

    // 1️⃣ Cargar sesión inicial
    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) {
        setAuth({
          isAuthenticated: true,
          loading: false,
          user: {
            auth_user_id: data.session.user.id,
            role: "UNKNOWN", // se ajusta luego
          } as any,
        });
      } else {
        setAuth({ ...INITIAL_AUTH, loading: false });
      }
    });

    // 2️⃣ Escuchar cambios de auth
    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (session?.user) {
          setAuth({
            isAuthenticated: true,
            loading: false,
            user: {
              auth_user_id: session.user.id,
              role: "UNKNOWN",
            } as any,
          });
        } else {
          setAuth({ ...INITIAL_AUTH, loading: false });
        }
      }
    );

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setAuth({ ...INITIAL_AUTH, loading: false });
  };

  return (
    <HashRouter>
      <Layout auth={auth} onLogout={handleLogout}>
        <AppRoutes auth={auth} />
      </Layout>
    </HashRouter>
  );
}
