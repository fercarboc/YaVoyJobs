Place landing images here:
- hero-vecinas.jpg (foto vertical de personas con movil)
- hero-ciudad.jpg (imagen calle con movil YaVoyJobs)
- hero-app.jpg (banner horizontal con dos telefonos)
