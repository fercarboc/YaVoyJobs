// Endpoint: POST /functions/v1/checkout-create
export default async (req, res) => {
  res.status(200).json({ message: 'Mock checkout-create endpoint' });
};
