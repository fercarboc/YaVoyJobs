// Endpoint: GET/PUT /functions/v1/provider-orders
export default async (req, res) => {
  res.status(200).json({ message: 'Mock provider-orders endpoint' });
};
