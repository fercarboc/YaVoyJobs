// Endpoint: GET/PUT /functions/v1/provider-returns
export default async (req, res) => {
  res.status(200).json({ message: 'Mock provider-returns endpoint' });
};
