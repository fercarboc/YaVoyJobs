// Endpoint: GET/POST/PUT/DELETE /functions/v1/provider-products
export default async (req, res) => {
  res.status(200).json({ message: 'Mock provider-products endpoint' });
};
