// Endpoint: GET /functions/v1/provider-invoices
export default async (req, res) => {
  res.status(200).json({ message: 'Mock provider-invoices endpoint' });
};
