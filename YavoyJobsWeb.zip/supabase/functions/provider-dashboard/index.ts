// Endpoint: GET /functions/v1/provider-dashboard
export default async (req, res) => {
  res.status(200).json({ message: 'Mock provider-dashboard endpoint' });
};
