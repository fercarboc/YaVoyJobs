export const COLORS = {
  primary: "#2563eb",
  success: "#10b981",
  danger: "#ef4444",
  warning: "#f59e0b",
  slate: "#0f172a",
};
